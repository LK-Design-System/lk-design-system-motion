# 제안 — 적응 계약 2세대 (남은 수동 손잡이 4개)

상태: **구현됨** (2026-08-17 작성·같은 날 구현. 변경 3은 **부분 활성** — Core
Stat의 `--lk-stat-*` 훅은 업스트림 main에 심었고(75b9e3b2, Table·Timeline
계약의 네 번째 사례), 위성 배선은 훅을 겨냥해 완료됐다. vendored 코어가
훅 이전(rc.69.27)이라 폴백이 현행 크기를 유지하며, **훅이 담긴 다음 코어
릴리스를 핀 범프하는 순간 수치 상향이 저절로 켜진다** — 위성 코드 변경
없이. 나머지 변경 1·2·4는 전면 활성)
근거: 구도·크기의 수동 교정은 덱마다 반복되는 비용이다(실측: 한 세션에서
지적 10라운드 이상 — eyebrow 크기, 타임라인 랭크, anchor, 표 폭). 1세대
적응(fit 사다리·분량→단 규칙·매체 폭 정책·잔여 높이 주도 전시물)이 같은
종류의 비용을 이미 지웠고, 이 제안은 **남아 있는 수동 손잡이 4개**를 같은
방식으로 지운다. 외부 근거: PPT SmartArt(개수 적응)와 적응형 제품군
(beautiful.ai Smart Slides) — 비교 레지스트리 §4·§5.

## 대원칙 — 순수 규칙만 (결정론 계약)

모든 적응은 **내용 유도**(prop으로 받은 데이터의 개수·분량)여야 하고 DOM
측정·ResizeObserver·벽시계에 기대면 안 된다. 모션 레포가 슬라이드를 "프레임
번호 → 정지 화면"의 순수 함수로 소비하기 때문이다 — sparseScale(분량→단)이
세운 전례를 따른다. 명시 prop은 언제나 규칙을 이긴다.

## 변경 1 — 덱 레벨 preset (E1)

`DeckViewer`(와 `PresenterView`)가 `preset`을 받아 컨텍스트로 내려주고,
슬라이드의 `preset` prop은 오버라이드가 된다. kind와 축이 대칭이 된다 —
실측: 파일럿 덱이 `preset="briefing"`을 4개 슬라이드에 반복 전달했다.

- 컨텍스트는 `{ preset, kind }` 하나(DeckMediumContext)로 묶는다 — 변경 2의
  read 분기가 같은 컨텍스트를 읽는다.
- 덱 밖(카탈로그 단독 렌더)에서는 컨텍스트가 없고, `data-slides-preset`
  미지정 → 기존처럼 keynote 토큰이 적용된다. 바이트 동일.

## 변경 2 — 위임 슬라이드의 anchor 자동화

"본문이 짧으면 center"는 이미 스킬 산문 규칙이다 — 기계로 내린다. 단
**위임 슬라이드에 한해서다**: 그들의 내용은 데이터 prop이라 개수를 순수하게
셀 수 있다. 자유 마크업(ContentSlide children)은 개수를 측정 없이 알 수
없으므로 수동 anchor가 유지된다(스킬 규칙 존치).

| 슬라이드 | 자동 규칙 | 근거 |
|---|---|---|
| StatSlide | 항상 center | 지표 행은 한 밴드다 — 위에 못박을 이유가 없다 (실측: 스트리밍 덱 수선에서 사람이 준 값과 동일) |
| RoadmapSlide | 항상 center | 가로 레일도 한 밴드다 (동일 실측) |
| AssessmentSlide | metrics ≤4 → center, 5+ → top | 작은 표는 밴드, 큰 표는 문서다 (관문 페이지 실측 2·2행 center) |
| CompareSlide | options ≤4 → center, 5+ → top | 동일 논리 |

- **read kind는 auto가 항상 top으로 해소된다** — 열람 페이지는 문서 흐름
  (마찰 6). 명시 `anchor="center"`는 read에서도 이긴다(명시는 규칙을
  이긴다; 장르 위반 여부는 루브릭의 몫).
- 명시 `anchor` prop은 어느 슬라이드에서든 규칙을 이긴다.

## 변경 3 — StatSlide 지표 개수 적응 (C2)

지표가 2개 이하면 수치가 한 단 올라간다: value가 title 단(40px) →
**display 단(56px)**. 3개 이상은 현행 유지.

- 구현은 훅 재지정이다: figures 컨테이너 스코프에서 Core Stat의
  `--lk-stat-value-*`를 `--slides-display-*`로 재지정 — 랭크 재지정이지
  임의 크기가 아니므로 프리셋 전환이 그대로 전파된다. (첫 시도는
  `--editorial-value-*`였는데, 그 seam은 KeyFigure의 수치에 닿지 않는다 —
  수치는 Core Stat이 그리고 Stat은 display2 직결이었다. 그래서 훅이
  업스트림에 필요했고, 이것이 네 번째 반복이 된 경위다.)
- **하향 단은 만들지 않는다**: title(40)과 body(24) 사이에 램프 단이 없고,
  5개 이상은 flexWrap이 이미 흡수한다. 임의 calc 크기는 램프 밖이라 기각.
- SmartArt("2개면 크게")의 절반만 채택하는 셈이며, 이는 램프 규율이 우선이기
  때문이다.

## 변경 4 — ExhibitRow 다행 적응

전시물 N장이 행·열을 스스로 정한다: **1~3장 = 1행 N열, 4장 = 2×2,
5~6장 = 3열 2행**. 7장 이상은 계약 밖(페이지를 쪼갤 신호 — 캡션이 읽히지
않는 밀도라서다; 스토리 주석에 명시).

- 행이 늘 때도 잔여 높이 주도 계약은 유지된다: `gridTemplateRows:
  repeat(rows, minmax(0, 1fr))` — 각 행이 부여 높이를 등분한다.

## 검증

- play 단언 4건: 덱 preset 컨텍스트 전파(+슬라이드 오버라이드), StatSlide
  2개→display 단·3개→title 단, 위임 auto-center(+read에서 top), ExhibitRow
  4장→2×2.
- 실전 덱 3벌 재렌더 눈 검수: 수동 preset·anchor 제거 후 렌더가 수선 시점과
  동일해야 한다 — **사람이 줬던 값을 규칙이 재현하는지가 이 제안의 합격선**이다.
- 게이트: canvas-under-fill은 center로 painted 하단이 내려가므로 완화 방향,
  오버플로는 변화 없음 예상. 전 체인 그린 필수.
